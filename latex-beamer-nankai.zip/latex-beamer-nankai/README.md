# An Unofficial LaTeX beamer style for Nankai University
=======================================================


**NOTE**

1. This is an UNOFFICIAL LaTeX beamer style for Nankai University.
2. These files are initially based on Edward Hartley's work <http://www-control.eng.cam.ac.uk/Main/EdwardHartley>. Xiaoke Yang <das.xiaoke@hotmail.com> from BUAA(Beihang University, 北京航空航天大学) gave a beihang version Beamer style from that work.
3. Complaints or suggestions are always welcome.